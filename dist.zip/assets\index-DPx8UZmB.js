(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),e.crossOrigin===`use-credentials`?t.credentials=`include`:e.crossOrigin===`anonymous`?t.credentials=`omit`:t.credentials=`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();var e=`/api`;async function t(){try{let t=await(await fetch(`${e}/site-config`)).json(),n=document.querySelector(`footer p`);n&&t.footer_text&&(n.textContent=t.footer_text)}catch(e){console.error(`Failed to fetch site config:`,e)}}async function n(){let t=document.getElementById(`tool-list`);if(t)try{t.innerHTML=(await(await fetch(`${e}/tools`)).json()).map(e=>{let t=e.status===`active`,n=t?`지금 이용 가능`:e.status===`coming_soon`?`출시 예정`:`개발 중...`,r=t?`무료 다운로드`:`곧 만나요`;return`
        <div class="tool-card">
          <div class="tool-icon">${e.icon||`🛠️`}</div>
          <div class="tool-info">
            <h3>[${t?`첫번째 필수 도구`:`준비 중`}: ${e.name}]</h3>
            <p>${e.description}</p>
            <span class="tool-status ${t?`status-active`:`status-pending`}">
              ${n}
            </span>
          </div>
          <div class="tool-action">
            <button class="btn ${t?`btn-primary`:`btn-disabled`}" 
                    ${t?``:`disabled`}>
              ${r}
            </button>
          </div>
        </div>
      `}).join(``)}catch(e){console.error(`Failed to fetch tools:`,e),t.innerHTML=`<p class="error-msg">도구 목록을 불러오는데 실패했습니다. 서버 상태를 확인해주세요.</p>`}}async function r(){try{let t=await(await fetch(`${e}/blog`)).json(),n=document.getElementById(`blog-list`);if(!n)return;n.innerHTML=t.map(e=>`
      <div class="blog-card">
        <img src="${e.thumbnail_url}" alt="${e.title}" class="blog-thumb">
        <div class="blog-content">
          <div class="blog-meta">
            <span class="badge ${e.difficulty_level}">${e.difficulty_level}</span>
            <span class="category">${e.category}</span>
          </div>
          <h3 class="blog-title">${e.title}</h3>
          <div class="blog-footer">
            <span>읽는 시간: ${e.estimated_time}분</span>
          </div>
        </div>
      </div>
    `).join(``)}catch(e){console.error(`Error fetching blog:`,e)}}document.addEventListener(`DOMContentLoaded`,()=>{t(),n(),r()});